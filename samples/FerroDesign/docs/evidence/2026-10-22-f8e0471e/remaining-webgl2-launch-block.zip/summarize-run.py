from pathlib import Path
import datetime
import hashlib
import json

root = Path('/tmp/ferrodesign-webgl2-tail-f8e0471e-9b313a0caa46')
report_dir = root / 'report'
manifest = json.loads((report_dir / 'validation-source.json').read_text())
report = json.loads((report_dir / 'report.json').read_text())
terminal = json.loads((root / 'terminal.json').read_text())

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return {'bytes': path.stat().st_size, 'sha256': h.hexdigest()}

integrity = {'checkedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'harnessFiles': {}, 'runtimeFiles': {}}
for section, base, target in [
    ('harnessFiles', Path(manifest['paths']['harness']), 'harnessFiles'),
    ('artifacts', Path(manifest['paths']['runtime']), 'runtimeFiles'),
]:
    for name, expected in manifest[section].items():
        actual = digest(base / name)
        integrity[target][name] = {**actual, 'matchesLaunchManifest': actual == expected}
integrity['all31SourceFilesUnchanged'] = len(integrity['harnessFiles']) == 31 and all(v['matchesLaunchManifest'] for v in integrity['harnessFiles'].values())
integrity['all16RuntimeFilesUnchanged'] = len(integrity['runtimeFiles']) == 16 and all(v['matchesLaunchManifest'] for v in integrity['runtimeFiles'].values())
(report_dir / 'post-run-integrity.json').write_text(json.dumps(integrity, indent=2) + '\n')

samples = [json.loads(line) for line in (root / 'resources.jsonl').read_text().splitlines()]
summary = {
    'created': report['created'], 'completedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'exitCode': terminal['exitCode'], 'durationSeconds': terminal['durationSeconds'],
    'passed': report['passed'], 'scope': report['scope'], 'browser': report['browser'],
    'harnessSourceCommit': manifest['harnessSourceCommit'], 'buildSourceCommit': manifest['buildSourceCommit'],
    'runtimeArtifactId': manifest['runtimeArtifact']['id'],
    'wasm': manifest['artifacts']['ferrodesign_app.wasm'],
    'predicateInstrumentation': False, 'results': [],
    'integrity': {
        'all31SourceFilesUnchanged': integrity['all31SourceFilesUnchanged'],
        'all16RuntimeFilesUnchanged': integrity['all16RuntimeFilesUnchanged'],
    },
    'resources': {
        'sampleCount': len(samples), 'sampleIntervalSeconds': 5,
        'baselineMemory': samples[0]['memoryCurrent'], 'finalMemory': samples[-1]['memoryCurrent'],
        'peakMemory': max(x['memoryCurrent'] for x in samples), 'memoryLimit': samples[0]['memoryMax'],
        'baselineEvents': samples[0]['memoryEvents'], 'finalEvents': samples[-1]['memoryEvents'],
        'eventsDelta': {k: samples[-1]['memoryEvents'][k] - v for k, v in samples[0]['memoryEvents'].items()},
        'peakOwnedSummedRssBytes': max(sum(p['rssPages'] for p in x['ownedProcesses']) * 4096 for x in samples),
        'finalOwnedProcesses': samples[-1]['ownedProcesses'],
        'caveat': 'Cgroup totals can include other work. Process samples match the Node PID or task Chromium executable path; they are not a complete descendant-tree or per-PID cgroup/PSS inventory, and skipped reads were not counted. Summed RSS includes shared pages and is not a unique allocation measurement.',
    },
}
for mode in report['results']:
    captures = mode.get('nativeCaptures', [])
    scenarios = mode.get('scenarios', [])
    summary['results'].append({
        'requestedRenderer': mode['requestedRenderer'], 'requestedMode': mode['requestedMode'],
        'actualSurface': mode.get('surface'), 'status': mode['status'], 'checks': len(mode['checks']),
        'scenariosEntered': sum(s['status'] != 'not-requested' for s in scenarios),
        'scenariosPassed': sum(s['status'] == 'passed' for s in scenarios), 'scenarios': scenarios,
        'nativeCaptures': len(captures), 'captureAttempts': sum(len(c['attempts']) for c in captures),
        'captureRetries': sum(len(c['attempts']) - 1 for c in captures),
        'allCaptureFinalAttemptsPassed': all(c['attempts'][-1]['status'] == 'passed' for c in captures),
        'retriedCaptures': [c for c in captures if len(c['attempts']) > 1],
        'pageErrors': mode['pageErrors'], 'consoleErrors': mode['consoleErrors'], 'error': mode.get('error'),
        'largeDocument': mode.get('largeDocument'),
    })
summary['rawFiles'] = {name: digest(root / name) for name in [
    'report/report.json', 'report/validation-source.json', 'report/input-equivalence.json',
    'report/post-run-integrity.json', 'browser.log', 'resources.jsonl', 'terminal.json',
]}
(root / 'terminal-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({
    'summary': str(root / 'terminal-summary.json'), 'passed': summary['passed'], 'scope': summary['scope'],
    'results': [{k: v for k, v in m.items() if k not in ['scenarios', 'retriedCaptures']} for m in summary['results']],
    'resources': summary['resources'], 'integrity': summary['integrity'],
}, indent=2))
