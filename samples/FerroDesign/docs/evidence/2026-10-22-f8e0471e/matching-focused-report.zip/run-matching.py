from pathlib import Path
import datetime
import json
import os
import subprocess
import time

root = Path('/tmp/ferrodesign-matching-f8e0471e-9b313a0caa46')
runtime = Path('/tmp/ferrodesign-full-f2bb1d61-9b313a0caa46')
cg = Path('/sys/fs/cgroup')

def pairs(name):
    return {line.split()[0]: int(line.split()[1]) for line in (cg / name).read_text().splitlines()}

def sample(child_pid=None):
    result = {
        'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'wallMs': time.time_ns() // 1000000,
        'memoryCurrent': int((cg / 'memory.current').read_text()),
        'memoryMax': int((cg / 'memory.max').read_text()),
        'memoryEvents': pairs('memory.events'),
        'memoryStat': pairs('memory.stat'),
        'cpuStat': pairs('cpu.stat'),
        'loadavg': Path('/proc/loadavg').read_text().strip(),
        'ownedProcesses': [],
    }
    for p in Path('/proc').glob('[0-9]*'):
        try:
            command = (p / 'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace')
            if int(p.name) != child_pid and str(runtime / 'chrome-linux64') not in command:
                continue
            values = (p / 'stat').read_text().split(') ', 1)[1].split()
            result['ownedProcesses'].append({
                'pid': int(p.name), 'state': values[0], 'parentPid': int(values[1]),
                'userTicks': int(values[11]), 'systemTicks': int(values[12]),
                'rssPages': int(values[21]),
                'role': next((x for x in command.split() if x.startswith('--type=')), 'node' if int(p.name) == child_pid else 'browser'),
            })
        except (FileNotFoundError, PermissionError, ProcessLookupError, IndexError):
            pass
    with (root / 'resources.jsonl').open('a') as output:
        output.write(json.dumps(result) + '\n')
    return result

baseline = sample()
headroom = baseline['memoryMax'] - baseline['memoryCurrent']
reclaimable_file = baseline['memoryStat'].get('inactive_file', 0)
if headroom < 768 * 1024**2 or headroom + reclaimable_file < 2500 * 1024**2:
    (root / 'launch-blocked.json').write_text(json.dumps({'reason': 'Insufficient cgroup memory headroom for one both-mode matching browser validation', 'baseline': baseline}, indent=2) + '\n')
    raise SystemExit(2)

env = os.environ.copy()
for name in ['FERRODESIGN_SCENARIOS', 'FERRODESIGN_MODES', 'FERRODESIGN_PREDICATE_DIAGNOSTICS']:
    env.pop(name, None)
env.update({
    'FERRODESIGN_SCENARIOS': 'matching',
    'FERRODESIGN_DIST': str(runtime / 'runtime'),
    'FERRODESIGN_CHROMIUM': str(runtime / 'chrome-linux64/chrome'),
    'FERRODESIGN_REPORT': str(root / 'report'),
})
manifest_path = root / 'report/validation-source.json'
manifest = json.loads(manifest_path.read_text())
manifest['runStarted'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
manifest['initialResources'] = {'memoryCurrent': baseline['memoryCurrent'], 'memoryMax': baseline['memoryMax'], 'headroomBytes': headroom, 'inactiveFileBytes': reclaimable_file, 'memoryEvents': baseline['memoryEvents']}
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
started = time.time()
with (root / 'browser.log').open('w') as output:
    child = subprocess.Popen(['node', 'tests/browser.mjs'], cwd=root / 'harness', env=env, stdout=output, stderr=subprocess.STDOUT)
    print(json.dumps({'started': True, 'nodePid': child.pid, 'headroomBytes': headroom, 'inactiveFileBytes': reclaimable_file}), flush=True)
    while child.poll() is None:
        sample(child.pid)
        time.sleep(5)
    returncode = child.wait()
final = sample(child.pid)
(root / 'terminal.json').write_text(json.dumps({'exitCode': returncode, 'durationSeconds': time.time() - started, 'baseline': baseline, 'final': final}, indent=2) + '\n')
print(json.dumps({'exitCode': returncode, 'durationSeconds': time.time() - started}), flush=True)
raise SystemExit(returncode)
